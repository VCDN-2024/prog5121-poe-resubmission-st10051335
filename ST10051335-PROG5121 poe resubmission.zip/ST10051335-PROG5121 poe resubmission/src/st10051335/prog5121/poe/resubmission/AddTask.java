package st10051335.prog5121.poe.resubmission;
import javax.swing.JOptionPane;

class AddTask {
      static String[] arrDeveloper = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"}; 
    static String[] arrTaskName = {"Create Login", "Create Add Features", "Create Reports", "Add Arrays"}; 
    static String[] arrtaskID = new String[10]; 
    static int[] arrtaskDuration = {5, 8, 2, 11}; 
    static String[] arrtaskStatus = {"To Do", "Doing", "Done", "To Do"}; 
    
    int total = 0;
    int taskNumber = arrDeveloper.length;
    String developerName;
    String taskName;
    int taskDuration;
    String taskStatus;
    String taskID;
    String taskDescription;
    
    public String getInput(String prompt) {
        return JOptionPane.showInputDialog(null, prompt);
    }
    
    public int showMenu() {
        while (true) {
            String input = getInput(
                "1. Add tasks\n" +
                "2. Show report\n" +
                "3. Quit"
            );

            if (input == null) {
                return 3;
            }

            try {
                int option = Integer.parseInt(input);
                if (option >= 1 && option <= 3) {
                    return option;
                }
            } catch (NumberFormatException e) {
            }
        }
    }
    
    public int Options() {
        while (true) {
            String input = getInput(
                "1. Display tasks that are done\n" +
                "2. Display the task with the longest duration\n" +
                "3. Search for a task by its name\n" +
                "4. Search for tasks assigned to a developer\n" +
                "5. Delete a task\n" +
                "6. Quit"
            );

            if (input == null) {
                return 6;
            }

            try {
                int option = Integer.parseInt(input);
                if (option >= 1 && option <= 6) {
                    return option;
                }
            } catch (NumberFormatException e) {
            }
        }
    }
    
    public void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks do you wish to enter?"));
        
        for (int i = 0; i < numTasks; i++) {
            taskName = JOptionPane.showInputDialog("Enter the name of the task:");
            
            do {
                taskDescription = JOptionPane.showInputDialog("Describe the task:");
                if (taskDescription == null || taskDescription.length() <= 50) {
                    JOptionPane.showMessageDialog(null, "Task successfully captured");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Enter a description of that is less than 50 characters");
                }
            } while (true);
            
            developerName = JOptionPane.showInputDialog("Enter the developer's full name for the task:");
            taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of hours the task would take:"));
            total += taskDuration;
            
            taskID = createTaskID(taskName, taskNumber, developerName);
            JOptionPane.showMessageDialog(null, "Task ID: " + taskID.toUpperCase());
                        
            while (true) {
                String input = getInput(
                    "1. To Do\n" +
                    "2. Done\n" +
                    "3. Doing"
                );

                if (input != null && !input.isEmpty()) {
                    int choice = Integer.parseInt(input);
                    if (choice == 1) {
                        taskStatus = "To Do";
                        break;
                    } else if (choice == 2) {
                        taskStatus = "Done";
                        break;
                    } else if (choice == 3) {
                        taskStatus = "Doing";
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error: You must select an option.");
                }
            }
            
            String taskDetails = printTaskDetails(taskStatus, developerName, taskNumber, taskName, taskDescription, taskID, taskDuration);
            JOptionPane.showMessageDialog(null, taskDetails);
            
            taskNumber++;
        }
        JOptionPane.showMessageDialog(null, "Total duration of all tasks: " + returnTotalHours() + " hours");
    }
    
    public boolean checkTaskDescription(String taskDescription) {
        return taskDescription != null && taskDescription.length() <= 50;
    }
    
    public String createTaskID(String taskName, int taskNumber, String developerName) {
        String prefix = taskName.substring(0, Math.min(taskName.length(), 2)).toUpperCase();
        String suffix = developerName.substring(Math.max(developerName.length() - 3, 0)).toUpperCase();
        return prefix + ":" + taskNumber + ":" + suffix;
    }
    
    public String printTaskDetails(String taskStatus, String developerDetails, int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration) {
        return String.format(
            "Task status: %s\nDeveloper details: %s\nTask number: %d\nTask name: %s\nTask description: %s\nTask ID: %s\nDuration: %d hours",
            taskStatus, developerDetails, taskNumber, taskName, taskDescription, taskID.toUpperCase(), taskDuration
        );
    }
    
    public int returnTotalHours() {
        return total;
    }
    
    public String display() {
        StringBuilder output = new StringBuilder("");
        boolean done = false;
        for (int i = 0; i < taskNumber; i++) {
            if (arrtaskStatus[i] != null && arrtaskStatus[i].equalsIgnoreCase("Done")) {
                output.append("\nTask name: ").append(arrTaskName[i]).append("\n");
                output.append("Developer's Name: ").append(arrDeveloper[i]).append("\n");
                output.append("Task Duration: ").append(arrtaskDuration[i]).append("\n\n");
                done = true;
            }
        }
        return output.toString();
        
    }
    
    public String MaxDuration() {
        int Duration = arrtaskDuration[0];
        int max = 0;

        for (int i = 1; i < taskNumber; i++) {
            if (arrtaskDuration[i] > Duration) {
                Duration = arrtaskDuration[i];
                max = i;
            }
        } 
        
        StringBuilder output = new StringBuilder("");
        output.append("Task name: ").append(arrTaskName[max]).append("\n");
        output.append("Developer's Name: ").append(arrDeveloper[max]).append("\n");
        output.append("Task Duration: ").append(arrtaskDuration[max]).append("\n");
        JOptionPane.showMessageDialog(null, output.toString());
        return output.toString();
    }
    
    public String Search(String name) {
        boolean found = false;
        StringBuilder output = new StringBuilder();
        
        for (int i = 0; i < taskNumber; i++) {
            if (arrTaskName[i].equalsIgnoreCase(name)) {
                output.append("\nTask name: ").append(arrTaskName[i]).append("\n");
                output.append("Developer's Name: ").append(arrDeveloper[i]).append("\n");
                output.append("Task Duration: ").append(arrtaskDuration[i]).append("\n");
                output.append("Task Status: ").append(arrtaskStatus[i]).append("\n\n");
                found = true;
            }
        }
        
        return output.toString();
    }

    public String SearchDeveloperDetails(String developerDetails) {
        boolean found = false;
        StringBuilder output = new StringBuilder();
        
        for (int i = 0; i < taskNumber; i++) {
            if (arrDeveloper[i].equalsIgnoreCase(developerDetails)) {
                output.append("\nTask name: ").append(arrTaskName[i]).append("\n");
                output.append("Developer's Name: ").append(arrDeveloper[i]).append("\n");
                output.append("Task Duration: ").append(arrtaskDuration[i]).append("\n");
                output.append("Task Status: ").append(arrtaskStatus[i]).append("\n\n");
                found = true;
            }
        }
        return output.toString();
    }
    
    public boolean Delete(String delete) {
        boolean found = false;
        int deleted = 0;
        for (int i = 0; i < taskNumber; i++) {
            if (arrTaskName[i].equalsIgnoreCase(delete)) {
                arrTaskName[i] = null;
                arrDeveloper[i] = null;
                arrtaskID[i] = null;
                arrtaskDuration[i] = 0;
                arrtaskStatus[i] = null;
                found = true;
                deleted++;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(null, deleted + " tasks with name '" + delete + "' were successfully deleted.");
        } 
        return true;
    }

}