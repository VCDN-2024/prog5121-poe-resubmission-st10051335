/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10051335.prog5121.part.pkg1;

/**
 *
 * @author lab_services_student
 */
class testSomeMethod {
    
}
